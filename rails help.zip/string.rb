puts "amir" 
firstname="muhammad"
lastname="amir"
puts "Enter your first name"
firstname=gets.chomp
puts "Enter your last name"
lastname=gets.chomp 
fulname=firstname+" "+lastname
puts "my full name=#{fulname}"

#puts fulname.class
#puts fulname.methods

